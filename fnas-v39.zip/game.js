
(()=>{
const $=id=>document.getElementById(id);
const cams=[
 {name:'CAM 1',place:'ANTRENMAN SAHASI',img:'assets/cam1-field.png'},
 {name:'CAM 2',place:'TESİS LOBİSİ',img:'assets/cam2-lobby.png'},
 {name:'CAM 3',place:'ANA KORİDOR',img:'assets/cam3-hallway.png'},
 {name:'CAM 4',place:'SOYUNMA ODASI',img:'assets/cam4-locker-room.png'},
 {name:'CAM 5',place:'DOĞU KORİDORU',img:'assets/cam5-corridor.png'},
 {name:'CAM 6',place:'ANTRENMAN SALONU',img:'assets/cam6-training-room.png'},
 {name:'CAM 1C',place:'ŞİŞELERLE DOLU ODA',img:'assets/cam1c-bottle-room.jpg'}
];
let running=false,monitor=false,cam=0,power=100,elapsed=0,nightSeconds=360,leftClosed=false,rightClosed=false,leftLit=false,rightLit=false,loop=null;
let night=Math.max(1,Math.min(5,Number(localStorage.getItem("fnsNight")||1))),foxState="waiting",foxTimer=null,attackAt=0,knockAudio=null,audioCtx=null,ambientOsc=null,ambientGain=null;
function drawMap(){const m=$('camMap');m.innerHTML='<svg viewBox="0 0 300 280" preserveAspectRatio="none"><path class="mapLine" d="M150 38 V78 H55 V110 M150 78 H245 V110 M55 110 V182 M245 110 V182 M55 182 H150 V232 M245 182 H150 V232 M150 232 V258"/></svg><div class="youNode">YOU</div>';const pos=['','','','','','',''];cams.forEach((c,i)=>{const b=document.createElement('button');b.className='camBtn'+(i===cam?' selected':'');b.dataset.cam=String(i);b.textContent=c.name;b.setAttribute('aria-label',c.name+' kamerasını aç');b.onclick=()=>{if(cam!==i){cam=i;cameraClick();drawFeed();drawMap()}};m.appendChild(b)})}
let cameraLoadToken=0;
function drawFeed(){const target=cams[cam].img,im=$('feedImg'),feed=$('feed'),token=++cameraLoadToken;feed.classList.add('loading');$('foxCharacter').classList.remove('visible');roamers.forEach(a=>$(a.el).classList.remove('visible'));$('runWarning').classList.remove('show');$('camName').textContent=cams[cam].name+' — '+cams[cam].place;const reveal=()=>{if(token!==cameraLoadToken)return;im.style.visibility='visible';feed.classList.remove('loading');updateFoxView()};im.onload=reveal;im.onerror=()=>{if(token!==cameraLoadToken)return;feed.classList.remove('loading');im.style.visibility='hidden';updateFoxView()};if(im.getAttribute('src')===target&&im.complete&&im.naturalWidth>0){reveal()}else{im.style.visibility='hidden';im.src=target}}
function audioReady(){try{const C=window.AudioContext||window.webkitAudioContext;if(!audioCtx)audioCtx=new C();if(audioCtx.state==='suspended')audioCtx.resume();return audioCtx}catch(e){return null}}
function tone(freq=120,duration=.12,volume=.12,type='triangle'){const c=audioReady();if(!c)return;try{const o=c.createOscillator(),g=c.createGain();o.type=type;o.frequency.setValueAtTime(freq,c.currentTime);g.gain.setValueAtTime(.0001,c.currentTime);g.gain.exponentialRampToValueAtTime(volume,c.currentTime+.012);g.gain.exponentialRampToValueAtTime(.0001,c.currentTime+duration);o.connect(g);g.connect(c.destination);o.start();o.stop(c.currentTime+duration+.02)}catch(e){}}
function cameraClick(){tone(760,.045,.055,'square');setTimeout(()=>tone(430,.06,.035,'square'),35)}
function controlSound(closed){tone(closed?95:210,.16,.16,'sawtooth');setTimeout(()=>tone(closed?65:160,.11,.08,'triangle'),55)}
function startAmbient(){const c=audioReady();if(!c||ambientOsc)return;try{ambientOsc=c.createOscillator();ambientGain=c.createGain();const filter=c.createBiquadFilter();ambientOsc.type='sawtooth';ambientOsc.frequency.value=48;filter.type='lowpass';filter.frequency.value=115;ambientGain.gain.value=.018;ambientOsc.connect(filter);filter.connect(ambientGain);ambientGain.connect(c.destination);ambientOsc.start()}catch(e){}}
function stopAmbient(){try{if(ambientOsc){ambientOsc.stop();ambientOsc=null;ambientGain=null}}catch(e){}}
const roamers=[
 {id:'lukaku',el:'lukakuCharacter',start:1,unlock:1,route:[1,0,2,3,4,5,6],door:'right',base:22,wait:0,approach:0},
 {id:'skriniar',el:'skriniarCharacter',start:3,unlock:1,route:[3,2,0,1,6,5,4],door:'left',base:24,wait:0,approach:0},
 {id:'guendouzi',el:'guendouziCharacter',start:5,unlock:3,route:[5,4,3,2,1,0,6],door:'right',base:28,wait:0,approach:0}
];
function updateFoxView(){
 const show=foxState==='waiting'&&cam===6&&monitor;
 $('foxCharacter').classList.toggle('visible',show);
 $('runWarning').classList.toggle('show',night>1&&foxState==='running'&&cam===6&&monitor);
 // Ismail Kartal stands centered on the circular platform in CAM 1C.
 $('foxCharacter').style.left='49%';$('foxCharacter').style.bottom='39%';$('foxCharacter').style.height='29%';$('foxCharacter').style.maxWidth='12%';$('foxCharacter').style.transform='translateX(-50%)';
 const leftAtDoor=roamers.some(a=>a.door==='left'&&a.approach>0);const rightAtDoor=roamers.some(a=>a.door==='right'&&a.approach>0);
 $('leftDoorEnemy').classList.toggle('visible',running&&!monitor&&leftLit&&leftAtDoor&&!leftClosed);$('rightDoorEnemy').classList.toggle('visible',running&&!monitor&&rightLit&&rightAtDoor&&!rightClosed);
 $('leftDoorEnemy').src=roamers.find(a=>a.door==='left'&&a.approach>0)?.id==='skriniar'?'assets/character-skriniar.png':'assets/character-fox.png';
 $('rightDoorEnemy').src=roamers.find(a=>a.door==='right'&&a.approach>0)?.id==='guendouzi'?'assets/character-guendouzi.png':'assets/character-lukaku.png';
 const positions={lukaku:'22%',skriniar:'62%',guendouzi:'42%'};
 roamers.forEach(a=>{
   const visible=running&&monitor&&a.approach===0&&a.route[a.pos]===cam;
   const el=$(a.el);el.classList.toggle('visible',visible);
   el.style.left=positions[a.id];el.style.bottom='7%';
 });
}
function planFox(){clearTimeout(foxTimer);foxState='waiting';attackAt=nightSeconds*.48+Math.floor(Math.random()*nightSeconds*.22);updateFoxView()}
function playScareSound(){try{const C=window.AudioContext||window.webkitAudioContext;const c=new C();const n=Math.floor(c.sampleRate*.42),b=c.createBuffer(1,n,c.sampleRate),d=b.getChannelData(0);for(let i=0;i<n;i++){const t=i/n;d[i]=(Math.random()*2-1)*(1-t)*.9+Math.sin(i*.11)*(1-t)*.3}const src=c.createBufferSource(),g=c.createGain(),f=c.createBiquadFilter();src.buffer=b;f.type='lowpass';f.frequency.setValueAtTime(4200,c.currentTime);f.frequency.exponentialRampToValueAtTime(180,c.currentTime+.38);g.gain.setValueAtTime(.9,c.currentTime);g.gain.exponentialRampToValueAtTime(.001,c.currentTime+.42);src.connect(f);f.connect(g);g.connect(c.destination);src.start();src.onended=()=>c.close()}catch(e){}}
function loseGame(who,side){if(!running)return;stopAmbient();running=false;clearInterval(loop);clearTimeout(foxTimer);toggleMonitor(false);leftLit=rightLit=false;update();const img=who==='İlk karakter'?'assets/character-fox.png':who==='Skriniar'?'assets/character-skriniar.png':who==='Guendouzi'?'assets/character-guendouzi.png':'assets/character-lukaku.png';$('jumpscareImg').src=img;$('jumpscare').classList.add('show');playScareSound();setTimeout(()=>{$('jumpscare').classList.remove('show');$('office').style.filter='brightness(.12) contrast(1.5)';setMessage('GAME OVER',(who+' '+(side==='left'?'sol':'sağ')+' kapıdan içeri girdi. Gece yeniden başlayacak.'),'TEKRAR DENE');$('message').classList.add('gameover');$('messageAction').onclick=()=>{ $('message').classList.remove('gameover');start() }},850)}
function resetRover(a){a.pos=0;a.approach=0;a.wait=Math.max(5,a.base-night*0.7)+Math.floor(Math.random()*4)}
function roverDoor(a){if(!running)return;const blocked=a.door==='left'?leftClosed:rightClosed;if(blocked){playKnocks(0);a.approach=0;a.pos=0;a.wait=12+Math.floor(Math.random()*7);updateFoxView()}else loseGame(a.id==='lukaku'?'Lukaku':a.id==='skriniar'?'Skriniar':'Guendouzi',a.door)}
function cameraGlitch(){
 if(!monitor)return;
 const g=$('feedGlitch');if(!g)return;
 g.classList.remove('flash');void g.offsetWidth;g.classList.add('flash');
 tone(105,.09,.045,'sawtooth');
}
function moveRovers(){if(!running)return;
 // FNAF-style rule: opening the camera monitor freezes EVERY character in place.
 // Their movement timers pause too, so no one can change rooms while the player watches CCTV.
 if(monitor)return;
 roamers.forEach(a=>{if(night<a.unlock)return;
 // Each character has a distinct counter-strategy: light, camera attention, or monitor use.
 if(a.id==='lukaku'&&rightLit&&a.approach===0){a.wait=Math.max(a.wait,2);return}
 if(a.wait>0){a.wait--;return}if(a.approach>0){a.approach--;if(a.approach===0)roverDoor(a);return}
 if(a.pos<a.route.length-1){cameraGlitch();a.pos++;tone(a.id==='skriniar'?58:a.id==='guendouzi'?72:88,.07,.025,'sine');let pace=a.base-night*1.15;if(a.id==='skriniar')pace=24-night*1.1;if(a.id==='guendouzi'&&night>=4)pace-=2;a.wait=Math.max(12,pace)+Math.floor(Math.random()*6)}else{a.approach=4+Math.floor(Math.random()*3);a.wait=0}
 });updateFoxView()}
function beginFoxRun(){if(!running||night<=1||foxState!=='waiting')return;foxState='running';updateFoxView();$('foxCharacter').classList.remove('visible');$('runWarning').classList.remove('show');foxTimer=setTimeout(foxAtDoor,8500)}
function foxAtDoor(){if(!running||foxState!=='running')return;if(leftClosed){foxState='knocking';playKnocks(0);setTimeout(()=>{foxState='waiting';planFox();updateFoxView()},2400)}else loseGame('İlk karakter','left')}
function playKnocks(n){if(n>=3)return;try{const C=window.AudioContext||window.webkitAudioContext;if(!knockAudio)knockAudio=new C();const ctx=knockAudio;const osc=ctx.createOscillator(),gain=ctx.createGain();osc.type='triangle';osc.frequency.setValueAtTime(75,ctx.currentTime);gain.gain.setValueAtTime(.0001,ctx.currentTime);gain.gain.exponentialRampToValueAtTime(.65,ctx.currentTime+.015);gain.gain.exponentialRampToValueAtTime(.0001,ctx.currentTime+.19);osc.connect(gain);gain.connect(ctx.destination);osc.start();osc.stop(ctx.currentTime+.2)}catch(e){}if(n<2)setTimeout(()=>playKnocks(n+1),650)}
function update(){updateFoxView(); $('leftDoor').classList.toggle('closed',leftClosed);$('rightDoor').classList.toggle('closed',rightClosed);$('leftGlow').classList.toggle('on',leftLit);$('rightGlow').classList.toggle('on',rightLit);$('leftDoorBtn').classList.toggle('active',leftClosed);$('rightDoorBtn').classList.toggle('active',rightClosed);$('leftLight').classList.toggle('active',leftLit);$('rightLight').classList.toggle('active',rightLit);const use=1+(leftClosed?1:0)+(rightClosed?1:0)+(leftLit?1:0)+(rightLit?1:0)+(monitor?1:0);$('usageText').textContent='USAGE: '+use;$('usage').innerHTML=Array.from({length:use},()=>'<i></i>').join('')}
function toggleMonitor(v){monitor=v;if(v){cameraClick();tone(145,.2,.07,'sawtooth')}else{tone(90,.16,.06,'sawtooth')}$('monitor').classList.toggle('show',v);$('camToggle').style.display=v?'none':'block';if(v){leftLit=false;rightLit=false;drawFeed();drawMap()}update()}
function setMessage(title,body,button){$('message').classList.remove('gameover','nightclear','victory');$('message').innerHTML='<h1>'+title+'</h1><div class="subtitle">THE LAST WATCH</div><p>'+body+'</p><button id="messageAction">'+button+'</button>'; $('messageAction').onclick=start;$('message').style.display='block'}
function endNight(){
 running=false;clearInterval(loop);clearTimeout(foxTimer);toggleMonitor(false);leftClosed=rightClosed=leftLit=rightLit=false;
 $('office').style.transition='filter 1s';$('office').style.filter='brightness(0)';
 $('jumpscare').classList.remove('show','powerOut');
 const bell=()=>{try{const C=window.AudioContext||window.webkitAudioContext,c=new C();[0,.22,.44].forEach((t,i)=>{const o=c.createOscillator(),g=c.createGain();o.type='sine';o.frequency.value=[880,1174,1568][i];g.gain.setValueAtTime(.0001,c.currentTime+t);g.gain.exponentialRampToValueAtTime(.22,c.currentTime+t+.02);g.gain.exponentialRampToValueAtTime(.0001,c.currentTime+t+.55);o.connect(g);g.connect(c.destination);o.start(c.currentTime+t);o.stop(c.currentTime+t+.56)});setTimeout(()=>c.close(),1800)}catch(e){}};
 bell();$('clock').textContent='6 AM';$('message').style.display='none';stopAmbient();
 setTimeout(()=>{$('office').style.filter='';$('office').style.transition='';if(night>=5){localStorage.setItem('fnsCompleted','true');setMessage('6 AM — TAMAMLANDI','Beş geceyi de atlattın. Samandıra tesislerinden sağ çıkmayı başardın.','ANA MENÜ');$('message').classList.add('victory');$('messageAction').onclick=()=>{night=1;localStorage.setItem('fnsNight','1');$('message').style.display='none';$('titleScreen').style.display='grid'};return}night++;localStorage.setItem('fnsNight',String(night));setMessage('12:00 AM','NIGHT '+night+'  —  Yeni gece başlıyor.','DEVAM ET');$('message').classList.add('nightclear');},2600)
}
function start(){$('titleScreen').style.display='none';$('message').style.display='none';running=true;monitor=false;cam=0;power=100;elapsed=0;startAmbient();$('power').style.color='#76d69b';foxState='waiting';roamers.forEach(a=>{a.pos=0;a.approach=0;a.wait=14+Math.floor(Math.random()*9)});leftClosed=rightClosed=leftLit=rightLit=false;$('clock').textContent='12 AM';$('nightLabel').textContent='GECE '+night;$('power').textContent='100%';$('office').style.filter='';$('message').style.display='none';$('camToggle').style.display='block';$('monitor').classList.remove('show');planFox();drawFeed();drawMap();update();clearInterval(loop);loop=setInterval(tick,1000)}
function powerOut(){if(!running)return;stopAmbient();running=false;clearInterval(loop);clearTimeout(foxTimer);monitor=false;leftClosed=rightClosed=leftLit=rightLit=false;$('monitor').classList.remove('show');$('camToggle').style.display='none';$('office').style.filter='brightness(0)';$('power').textContent='0%';$('power').style.color='#ff3030';$('jumpscareImg').src='assets/character-fox.png';$('jumpscare').classList.add('powerOut');playScareSound();setTimeout(()=>{if(!$('jumpscare').classList.contains('powerOut'))return;$('jumpscare').classList.remove('powerOut');$('jumpscare').classList.add('show');playScareSound();setTimeout(()=>{$('jumpscare').classList.remove('show');$('office').style.filter='brightness(.08)';setMessage('GAME OVER','Enerji tamamen tükendi. Karanlıkta İsmail Kartal seni buldu.','TEKRAR DENE');$('message').classList.add('gameover');$('messageAction').onclick=()=>{$('message').classList.remove('gameover');start()}},850)},6500)}
function tick(){if(!running)return;elapsed++;moveRovers();let use=1+(leftClosed?1:0)+(rightClosed?1:0)+(leftLit?1:0)+(rightLit?1:0)+(monitor?1:0);power=Math.max(0,power-(.105+(.105*(use-1))));$('power').textContent=Math.ceil(power)+'%';$('power').style.color=power<20?'#ff555d':'#76d69b';let hour=Math.min(6,Math.floor(elapsed/(nightSeconds/6)));$('clock').textContent=hour===0?'12 AM':hour+' AM';if(power<=0){powerOut();return}if(night>1&&foxState==='waiting'&&elapsed>=attackAt)beginFoxRun();if(elapsed>=nightSeconds){endNight();return}update()}
$('newGameHit').onclick=start;$('camToggle').onclick=()=>{if(running)toggleMonitor(!monitor)};$('closeCam').onclick=()=>toggleMonitor(false);
$('leftDoorBtn').onclick=()=>{if(!running||monitor)return;leftClosed=!leftClosed;controlSound(leftClosed);update()};$('rightDoorBtn').onclick=()=>{if(!running||monitor)return;rightClosed=!rightClosed;controlSound(rightClosed);update()};
$('leftLight').onclick=()=>{if(!running||monitor)return;leftLit=!leftLit;tone(leftLit?520:250,.08,.04,'square');update()};$('rightLight').onclick=()=>{if(!running||monitor)return;rightLit=!rightLit;tone(rightLit?520:250,.08,.04,'square');update()};
drawMap();drawFeed();update();document.addEventListener('keydown',e=>{if(!running)return;const k=e.key.toLowerCase();if(k===' '||k==='c'){e.preventDefault();toggleMonitor(!monitor)}if(k==='escape'&&monitor)toggleMonitor(false);if(k==='q')$('leftLight').click();if(k==='a')$('leftDoorBtn').click();if(k==='e')$('rightLight').click();if(k==='d')$('rightDoorBtn').click()});
})();
