
(()=>{
const $=id=>document.getElementById(id);
const cams=[
 {name:'CAM 1',place:'ANTRENMAN SAHASI',img:'assets/cam1-field.png'},
 {name:'CAM 2',place:'TESİS LOBİSİ',img:'assets/cam2-lobby.png'},
 {name:'CAM 3',place:'ANA KORİDOR',img:'assets/cam3-hallway.png'},
 {name:'CAM 4',place:'SOYUNMA ODASI',img:'assets/cam4-locker-room.png'},
 {name:'CAM 5',place:'DOĞU KORİDORU',img:'assets/cam5-corridor.png'},
 {name:'CAM 6',place:'ANTRENMAN SALONU',img:'assets/cam6-training-room.png'},
 {name:'CAM 1C',place:'ŞİŞELERLE DOLU ODA',img:'assets/cam1c-bottle-room.jpg'}
];
let running=false,monitor=false,cam=0,power=100,elapsed=0,nightSeconds=360,leftClosed=false,rightClosed=false,leftLit=false,rightLit=false,loop=null;
let night=Math.max(1,Number(localStorage.getItem("fnsNight")||1)),foxState="waiting",foxTimer=null,attackAt=0,knockAudio=null;
function drawMap(){const m=$('camMap');m.innerHTML='<svg viewBox="0 0 300 280" preserveAspectRatio="none"><path class="mapLine" d="M150 38 V78 H55 V110 M150 78 H245 V110 M55 110 V182 M245 110 V182 M55 182 H150 V232 M245 182 H150 V232 M150 232 V258"/></svg><div class="youNode">YOU</div>';const pos=['','','','','','',''];cams.forEach((c,i)=>{const b=document.createElement('button');b.className='camBtn'+(i===cam?' selected':'');b.dataset.cam=String(i);b.textContent=c.name;b.setAttribute('aria-label',c.name+' kamerasını aç');b.onclick=()=>{cam=i;drawFeed();drawMap()};m.appendChild(b)})}
function drawFeed(){$('camName').textContent=cams[cam].name+' — '+cams[cam].place;$('feedImg').src=cams[cam].img;updateFoxView()}
const roamers=[
 {id:'lukaku',el:'lukakuCharacter',start:1,unlock:1,route:[1,0,2,3,4,5,6],door:'right',base:10,wait:0,approach:0},
 {id:'skriniar',el:'skriniarCharacter',start:3,unlock:1,route:[3,2,0,1,6,5,4],door:'left',base:9,wait:0,approach:0},
 {id:'guendouzi',el:'guendouziCharacter',start:5,unlock:3,route:[5,4,3,2,1,0,6],door:'right',base:14,wait:0,approach:0}
];
function updateFoxView(){const show=foxState==='waiting'&&cam===6&&monitor;$('foxCharacter').classList.toggle('visible',show);$('runWarning').classList.toggle('show',night>1&&foxState==='running'&&cam===6&&monitor);
roamers.forEach(a=>$(a.el).classList.toggle('visible',running&&monitor&&a.wait>=0&&a.approach===0&&a.route[a.pos]===cam));
}
function planFox(){clearTimeout(foxTimer);foxState='waiting';attackAt=nightSeconds*.48+Math.floor(Math.random()*nightSeconds*.22);updateFoxView()}
function loseGame(who,side){running=false;clearInterval(loop);clearTimeout(foxTimer);toggleMonitor(false);$('office').style.filter='brightness(.12) contrast(1.5)';setMessage('YAKALANDIN!',(who+' '+(side==='left'?'sol':'sağ')+' kapıdan içeri girdi. Gece yeniden başlayacak.'),'TEKRAR DENE');$('messageAction').onclick=()=>{start()}}
function resetRover(a){a.pos=0;a.approach=0;a.wait=Math.max(5,a.base-night*0.7)+Math.floor(Math.random()*4)}
function roverDoor(a){if(!running)return;const blocked=a.door==='left'?leftClosed:rightClosed;if(blocked){playKnocks(0);a.approach=0;a.pos=0;a.wait=12+Math.floor(Math.random()*7);updateFoxView()}else loseGame(a.id==='lukaku'?'Lukaku':a.id==='skriniar'?'Skriniar':'Guendouzi',a.door)}
function moveRovers(){if(!running)return;roamers.forEach(a=>{if(night<a.unlock)return;if(a.wait>0){a.wait--;return}if(a.approach>0){a.approach--;if(a.approach===0)roverDoor(a);return}if(a.pos<a.route.length-1){a.pos++;a.wait=Math.max(4,a.base-night*0.8)+Math.floor(Math.random()*4)}else{a.approach=4+Math.floor(Math.random()*3);a.wait=0}});updateFoxView()}
function beginFoxRun(){if(!running||night<=1||foxState!=='waiting')return;foxState='running';updateFoxView();$('foxCharacter').classList.remove('visible');$('runWarning').classList.remove('show');foxTimer=setTimeout(foxAtDoor,8500)}
function foxAtDoor(){if(!running||foxState!=='running')return;if(leftClosed){foxState='knocking';playKnocks(0);setTimeout(()=>{foxState='waiting';planFox();updateFoxView()},2400)}else loseGame('İlk karakter','left')}
function playKnocks(n){if(n>=3)return;try{const C=window.AudioContext||window.webkitAudioContext;if(!knockAudio)knockAudio=new C();const ctx=knockAudio;const osc=ctx.createOscillator(),gain=ctx.createGain();osc.type='triangle';osc.frequency.setValueAtTime(75,ctx.currentTime);gain.gain.setValueAtTime(.0001,ctx.currentTime);gain.gain.exponentialRampToValueAtTime(.65,ctx.currentTime+.015);gain.gain.exponentialRampToValueAtTime(.0001,ctx.currentTime+.19);osc.connect(gain);gain.connect(ctx.destination);osc.start();osc.stop(ctx.currentTime+.2)}catch(e){}if(n<2)setTimeout(()=>playKnocks(n+1),650)}
function update(){updateFoxView(); $('leftDoor').classList.toggle('closed',leftClosed);$('rightDoor').classList.toggle('closed',rightClosed);$('leftGlow').classList.toggle('on',leftLit);$('rightGlow').classList.toggle('on',rightLit);$('leftDoorBtn').classList.toggle('active',leftClosed);$('rightDoorBtn').classList.toggle('active',rightClosed);$('leftLight').classList.toggle('active',leftLit);$('rightLight').classList.toggle('active',rightLit);const use=1+(leftClosed?1:0)+(rightClosed?1:0)+(leftLit?1:0)+(rightLit?1:0)+(monitor?1:0);$('usageText').textContent='USAGE: '+use;$('usage').innerHTML=Array.from({length:use},()=>'<i></i>').join('')}
function toggleMonitor(v){monitor=v;$('monitor').classList.toggle('show',v);$('camToggle').style.display=v?'none':'block';if(v){leftLit=false;rightLit=false;drawFeed();drawMap()}update()}
function setMessage(title,body,button){$('message').innerHTML='<h1>'+title+'</h1><div class="subtitle">THE LAST WATCH</div><p>'+body+'</p><button id="messageAction">'+button+'</button>'; $('messageAction').onclick=start;$('message').style.display='block'}
function endNight(){running=false;clearInterval(loop);clearTimeout(foxTimer);toggleMonitor(false);night=Math.min(5,night+1);localStorage.setItem('fnsNight',String(night));setMessage('06 AM','Geceyi tamamladın. Sonraki vardiyaya hazırsın.','GECE '+night+' BAŞLAT')}
function start(){running=true;monitor=false;cam=0;power=100;elapsed=0;foxState='waiting';roamers.forEach(a=>{a.pos=0;a.approach=0;a.wait=10+Math.floor(Math.random()*7)});leftClosed=rightClosed=leftLit=rightLit=false;$('clock').textContent='12 AM';$('nightLabel').textContent='GECE '+night;$('power').textContent='100%';$('office').style.filter='';$('message').style.display='none';$('camToggle').style.display='block';$('monitor').classList.remove('show');planFox();drawFeed();drawMap();update();clearInterval(loop);loop=setInterval(tick,1000)}
function tick(){if(!running)return;elapsed++;moveRovers();let use=1+(leftClosed?1:0)+(rightClosed?1:0)+(leftLit?1:0)+(rightLit?1:0)+(monitor?1:0);power=Math.max(0,power-(.12+(.045*(use-1))));$('power').textContent=Math.ceil(power)+'%';$('power').style.color=power<20?'#ff555d':'#76d69b';let hour=Math.min(6,Math.floor(elapsed/(nightSeconds/6)));$('clock').textContent=hour===0?'12 AM':hour+' AM';if(power<=0){leftClosed=rightClosed=leftLit=rightLit=false;toggleMonitor(false);$('office').style.filter='brightness(.08)';$('power').textContent='0%';}if(night>1&&foxState==='waiting'&&elapsed>=attackAt)beginFoxRun();if(elapsed>=nightSeconds){endNight();return}update()}
$('startBtn').onclick=start;$('camToggle').onclick=()=>{if(running)toggleMonitor(!monitor)};$('closeCam').onclick=()=>toggleMonitor(false);
$('leftDoorBtn').onclick=()=>{if(!running||monitor)return;leftClosed=!leftClosed;update()};$('rightDoorBtn').onclick=()=>{if(!running||monitor)return;rightClosed=!rightClosed;update()};
$('leftLight').onclick=()=>{if(!running||monitor)return;leftLit=!leftLit;update()};$('rightLight').onclick=()=>{if(!running||monitor)return;rightLit=!rightLit;update()};
drawMap();drawFeed();update();document.addEventListener('keydown',e=>{if(!running)return;const k=e.key.toLowerCase();if(k===' '||k==='c'){e.preventDefault();toggleMonitor(!monitor)}if(k==='escape'&&monitor)toggleMonitor(false);if(k==='q')$('leftLight').click();if(k==='a')$('leftDoorBtn').click();if(k==='e')$('rightLight').click();if(k==='d')$('rightDoorBtn').click()});
})();
