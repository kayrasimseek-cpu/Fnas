FNAS — Netlify PWA sürümü v24

Netlify'a yükleme:
1. ZIP'i açmadan https://app.netlify.com/drop sayfasına yükleyin.
2. Yayınlanan HTTPS adresini Chrome'da açın.
3. Sayfa tamamen yüklendikten sonra Chrome menüsünden 'Uygulamayı yükle' veya 'Yükle ve kısayol oluştur' seçeneğini deneyin.
4. Eski bir FNAS kurulumu varsa önce kaldırın; siteyi Chrome'da açıp yenileyin.

Bu sürümde PWA manifest yolu kökten tanımlandı ve service worker önbellek kurulumu tek bir dosyanın başarısız olmasına bağlı olmaktan çıkarıldı.
